/*
INI SC GW PRIBADI
*/
// [❗] SC YNG BIKIN GW STRES AHHAHAHHA

const xxx = '```'
const tz = '►'
const prefix = '#' 
exports.menuZ = (ownername, pushname, prefix, auth0r, bulan, tz) => {
	return`◪ INFO DEVELOPER
  ► Other : ROXY GANZ
  ► WhatsApp : Wa.me/6289637093889
  ► Owner : ROXY GANTENG
  ----------------------------------
◪ YOUR INFO
${xxx}► Prefix : 「 ${prefix} 」${xxx}
${xxx}► Bulan🌙: ${bulan}${xxx}
${xxx}► Nama : ${pushname}${xxx}
  ----------------------------------
  *◪PENTING*
*OI ASU YANG SPAM BOT*
*YANG TELPON BOT*
*TOLONG LAH OTAK GW DH STRES*
*LOGO JUGA BELUM JADI*
*LU BIKIN OTAK GW MAKIN STRES AJG*
  ----------------------------------
*BISA BACA?*
${prefix}peraturan
${prefix}kenapasayadiban

  *◪ GROUP MENU*
${tz}${prefix}${xxx}hidetag${xxx}
${tz}${prefix}${xxx}add${xxx}
${tz}${prefix}${xxx}kick${xxx}
${tz}${prefix}${xxx}promote${xxx}
${tz}${prefix}${xxx}demote${xxx}
${tz}${prefix}${xxx}antilink${xxx}
${tz}${prefix}${xxx}welcome${xxx}
${tz}${prefix}${xxx}hidetag10${xxx}
${tz}${prefix}${xxx}group${xxx}
${tz}${prefix}${xxx}antigay${xxx}
${tz}${prefix}${xxx}antibocil${xxx}
${tz}${prefix}${xxx}antiwibu${xxx}
${tz}${prefix}${xxx}antikasar${xxx}
${tz}${prefix}${xxx}antitag${xxx}
${tz}${prefix}${xxx}level${xxx}
${tz}${prefix}${xxx}limit${xxx}
${tz}${prefix}${xxx}leveling${xxx}
${tz}${prefix}${xxx}antijawa${xxx} 
${tz}${prefix}${xxx}katajago${xxx}
${tz}${prefix}${xxx}linkgc${xxx}
${tz}${prefix}${xxx}tagall${xxx}
${tz}${prefix}${xxx}delete${xxx}

  *◪ OWNER MENU*
${tz}${prefix}${xxx}tagall${xxx}
${tz}${prefix}${xxx}hidetag${xxx}
${tz}${prefix}${xxx}unban${xxx}
${tz}${prefix}${xxx}ban${xxx}
${tz}${prefix}${xxx}dellprem${xxx} 
${tz}${prefix}${xxx}addprem${xxx}
${tz}${prefix}${xxx}clearall${xxx}
${tz}${prefix}${xxx}bc${xxx}
${tz}${prefix}${xxx}owner${xxx}
${tz}${prefix}${xxx}author${xxx}
${tz}${prefix}${xxx}bugtroli${xxx}
${tz}${prefix}${xxx}setout${xxx}
${tz}${prefix}${xxx}setwelcome${xxx}
${tz}${prefix}${xxx}settz${xxx}
${tz}${prefix}${xxx}setthum${xxx}
${tz}${prefix}${xxx}setpp${xxx}
${tz}${prefix}${xxx}setprefix${xxx}
${tz}${prefix}${xxx}setreply${xxx}

  *◪ PRO MENU*
${tz}${prefix}${xxx}nulis1${xxx}
${tz}${prefix}${xxx}nulis2${xxx}
${tz}${prefix}${xxx}nulis3${xxx}
${tz}${prefix}${xxx}nulis4${xxx}
${tz}${prefix}${xxx}nulis5${xxx}
${tz}${prefix}${xxx}nulis6${xxx}
${tz}${prefix}${xxx}video1${xxx}
${tz}${prefix}${xxx}video2${xxx}
${tz}${prefix}${xxx}video3${xxx}
${tz}${prefix}${xxx}video4${xxx}
${tz}${prefix}${xxx}video5${xxx}
${tz}${prefix}${xxx}video6${xxx}

  *◪ DOWNLOAD*
${tz}${prefix}${xxx}telesticker${xxx}
${tz}${prefix}${xxx}tiktokmusic${xxx}
${tz}${prefix}${xxx}tiktoknowm${xxx}
${tz}${prefix}${xxx}igfoto${xxx}
${tz}${prefix}${xxx}igvideo${xxx}
${tz}${prefix}${xxx}ytsearch${xxx}
${tz}${prefix}${xxx}ytmp3${xxx}
${tz}${prefix}${xxx}ytmp4${xxx}
${tz}${prefix}${xxx}play${xxx}

  *◪SOUND*
${tz}${prefix}${xxx}tomp3${xxx}
${tz}${prefix}${xxx}sound1${xxx}
${tz}${prefix}${xxx}sound2${xxx}
${tz}${prefix}${xxx}sound3${xxx}
${tz}${prefix}${xxx}sound4${xxx}
${tz}${prefix}${xxx}sound5${xxx}
${tz}${prefix}${xxx}sound6${xxx}
${tz}${prefix}${xxx}sound7${xxx}
${tz}${prefix}${xxx}sound8${xxx}
${tz}${prefix}${xxx}sound9${xxx}
${tz}${prefix}${xxx}sound10${xxx}
${tz}${prefix}${xxx}sound11${xxx}
${tz}${prefix}${xxx}sound12${xxx}
${tz}${prefix}${xxx}sound13${xxx}
${tz}${prefix}${xxx}sound14${xxx}
${tz}${prefix}${xxx}sound15${xxx}
${tz}${prefix}${xxx}sound16${xxx}
${tz}${prefix}${xxx}sound17${xxx}
${tz}${prefix}${xxx}sound18${xxx}
${tz}${prefix}${xxx}sound19${xxx}
${tz}${prefix}${xxx}sound20${xxx}
${tz}${prefix}${xxx}sound21${xxx}
${tz}${prefix}${xxx}sound22${xxx}
${tz}${prefix}${xxx}sound23${xxx}
${tz}${prefix}${xxx}sound24${xxx}
${tz}${prefix}${xxx}sound25${xxx}

  *◪INTERNAL MENU*
${tz}${prefix}${xxx}readmore${xxx}
${tz}${prefix}${xxx}chatlist${xxx}
${tz}${prefix}${xxx}addsticker${xxx}
${tz}${prefix}${xxx}addvn${xxx}
${tz}${prefix}${xxx}getvn${xxx}
${tz}${prefix}${xxx}getsticker${xxx}
${tz}${prefix}${xxx}liststicker${xxx}
${tz}${prefix}${xxx}listvn${xxx}
${tz}${prefix}${xxx}addimage${xxx}
${tz}${prefix}${xxx}getimage${xxx}
${tz}${prefix}${xxx}imagelist${xxx}
${tz}${prefix}${xxx}addvideo${xxx}
${tz}${prefix}${xxx}getvideo${xxx}
${tz}${prefix}${xxx}listvideo${xxx}

  *◪WIBU CEK:V*
${tz}${prefix}${xxx}bisakah${xxx}
${tz}${prefix}${xxx}kapankah${xxx}
${tz}${prefix}${xxx}apakah${xxx}
${tz}${prefix}${xxx}bagaimanakah${xxx}
${tz}${prefix}${xxx}gantengcek${xxx}
${tz}${prefix}${xxx}cantikcek${xxx}
${tz}${prefix}${xxx}jelekcek${xxx}
${tz}${prefix}${xxx}goblokcek${xxx}
${tz}${prefix}${xxx}begocek${xxx}
${tz}${prefix}${xxx}pintercek${xxx}
${tz}${prefix}${xxx}jagocek${xxx}
${tz}${prefix}${xxx}nolepcek${xxx}
${tz}${prefix}${xxx}babicek${xxx}
${tz}${prefix}${xxx}bebancek${xxx}
${tz}${prefix}${xxx}baikcek${xxx}
${tz}${prefix}${xxx}jahatcek${xxx}
${tz}${prefix}${xxx}anjingcek${xxx}
${tz}${prefix}${xxx}haramcek${xxx}
${tz}${prefix}${xxx}kontolcek${xxx}
${tz}${prefix}${xxx}pakboycek${xxx}
${tz}${prefix}${xxx}pakgirlcek${xxx}
${tz}${prefix}${xxx}sangecek${xxx}
${tz}${prefix}${xxx}bapercek${xxx}

  *◪SPESIAL MENU*
${tz}${prefix}${xxx}randomwibu${xxx}
${tz}${prefix}${xxx}phkomen${xxx}
${tz}${prefix}${xxx}semoji${xxx}
${tz}${prefix}${xxx}jadian${xxx}
${tz}${prefix}${xxx}citacita${xxx}
${tz}${prefix}${xxx}laut${xxx}
${tz}${prefix}${xxx}darat${xxx}
${tz}${prefix}${xxx}udara${xxx}
${tz}${prefix}${xxx}fakta${xxx}
${tz}${prefix}${xxx}gcard${xxx}
${tz}${prefix}${xxx}ssweb${xxx}
${tz}${prefix}${xxx}katailham${xxx}
${tz}${prefix}${xxx}randomwibu${xxx}

  *◪TAG MENU*
${tz}${prefix}${xxx}ganteng${xxx}
${tz}${prefix}${xxx}cantik${xxx}
${tz}${prefix}${xxx}jelek${xxx}
${tz}${prefix}${xxx}goblok${xxx}
${tz}${prefix}${xxx}bego${xxx}
${tz}${prefix}${xxx}pinter${xxx}
${tz}${prefix}${xxx}jago${xxx}
${tz}${prefix}${xxx}babi${xxx}
${tz}${prefix}${xxx}beban${xxx}
${tz}${prefix}${xxx}baik${xxx}
${tz}${prefix}${xxx}jahat${xxx}
${tz}${prefix}${xxx}anjing${xxx}
${tz}${prefix}${xxx}monyet${xxx}
${tz}${prefix}${xxx}haram${xxx}
${tz}${prefix}${xxx}kontol${xxx}
${tz}${prefix}${xxx}pakboy${xxx}
${tz}${prefix}${xxx}pakgirl${xxx}
${tz}${prefix}${xxx}sadboy${xxx}
${tz}${prefix}${xxx}sadgirl${xxx}
${tz}${prefix}${xxx}wibu${xxx}
${tz}${prefix}${xxx}nolep${xxx}
${tz}${prefix}${xxx}hebat${xxx}

  *◪GAME*
${tz}${prefix}${xxx}slot${xxx}
${tz}${prefix}${xxx}simi${xxx}
${tz}${prefix}${xxx}jumlah${xxx}
${tz}${prefix}${xxx}hurufkebalik${xxx}
${tz}${prefix}${xxx}tebakgambar${xxx}
${tz}${prefix}${xxx}truth${xxx}
${tz}${prefix}${xxx}dare${xxx}
${tz}${prefix}${xxx}nickff${xxx}
${tz}${prefix}${xxx}kapankah${xxx}
${tz}${prefix}${xxx}apakah${xxx}
${tz}${prefix}${xxx}ramalnomer${xxx} 
${tz}${prefix}${xxx}ramalcinta${xxx} 
${tz}${prefix}${xxx}jodohbali${xxx} 
${tz}${prefix}${xxx}ramalnikah${xxx} 
${tz}${prefix}${xxx}taksirmimpi${xxx} 
${tz}${prefix}${xxx}suit${xxx}                   
${tz}${prefix}${xxx}boomtext${xxx}
${tz}${prefix}${xxx}holoh${xxx}
${tz}${prefix}${xxx}heleh${xxx}
${tz}${prefix}${xxx}huluh${xxx}
${tz}${prefix}${xxx}hilih${xxx}
${tz}${prefix}${xxx}halah${xxx} 
${tz}${prefix}${xxx}kapital${xxx}
${tz}${prefix}${xxx}textfont${xxx}
${tz}${prefix}${xxx}tebak${xxx}
${tz}${prefix}${xxx}oxo${xxx}
${tz}${prefix}${xxx}pesan${xxx}
${tz}${prefix}${xxx}tebakkimia${xxx}
${tz}${prefix}${xxx}tebaklirik${xxx}
${tz}${prefix}${xxx}tebakin1${xxx}
${tz}${prefix}${xxx}tebakin2${xxx}

  *◪RANDOM TEXT*
${tz}${prefix}${xxx}quotes2${xxx}
${tz}${prefix}${xxx}grubwa${xxx}
${tz}${prefix}${xxx}brainly${xxx}
${tz}${prefix}${xxx}quotes1${xxx}
${tz}${prefix}${xxx}kusonime${xxx}
${tz}${prefix}${xxx}renungan${xxx}
${tz}${prefix}${xxx}samehadaku${xxx}
${tz}${prefix}${xxx}infonomer${xxx}
${tz}${prefix}${xxx}jadwaltv${xxx}
${tz}${prefix}${xxx}tvjadwal${xxx}
${tz}${prefix}${xxx}fml${xxx}
${tz}${prefix}${xxx}cinta${xxx}
${tz}${prefix}${xxx}resepmasakan${xxx}
${tz}${prefix}${xxx}cersex${xxx}
${tz}${prefix}${xxx}cerpen${xxx}
${tz}${prefix}${xxx}jadwalsholat${xxx}
${tz}${prefix}${xxx}pantun${xxx}
${tz}${prefix}${xxx}cuaca${xxx}
${tz}${prefix}${xxx}namaninja${xxx}
${tz}${prefix}${xxx}fake${xxx}
${tz}${prefix}${xxx}spamcall${xxx}
${tz}${prefix}${xxx}spamemail${xxx}
${tz}${prefix}${xxx}quotes${xxx}
${tz}${prefix}${xxx}quotesnime${xxx}
${tz}${prefix}${xxx}kbbilazimedia${xxx}
${tz}${prefix}${xxx}covid${xxx}
${tz}${prefix}${xxx}wikiid${xxx}
${tz}${prefix}${xxx}wikien${xxx}
${tz}${prefix}${xxx}covidid${xxx}
${tz}${prefix}${xxx}kbbi${xxx}
${tz}${prefix}${xxx}infogempa${xxx}
${tz}${prefix}${xxx}randomquran${xxx}
${tz}${prefix}${xxx}kisanabi${xxx}
${tz}${prefix}${xxx}artinama${xxx}
${tz}${prefix}${xxx}artimimpi${xxx}
${tz}${prefix}${xxx}artijadian${xxx}
${tz}${prefix}${xxx}chord${xxx}
${tz}${prefix}${xxx}lirik${xxx}

  *◪FAST MENU*
${tz}${prefix}${xxx}fb${xxx}
${tz}${prefix}${xxx}tts${xxx}
${tz}${prefix}${xxx}steam${xxx}
${tz}${prefix}${xxx}stalktwit${xxx}
${tz}${prefix}${xxx}stalkgithub${xxx} 
${tz}${prefix}${xxx}randomhusbu${xxx}
${tz}${prefix}${xxx}pinterest${xxx}
${tz}${prefix}${xxx}randomwaifu${xxx}
${tz}${prefix}${xxx}randomwaifu1${xxx}
${tz}${prefix}${xxx}stalkig${xxx}
${tz}${prefix}${xxx}estetikpic${xxx}
${tz}${prefix}${xxx}memeindo${xxx}
${tz}${prefix}${xxx}darkjokes${xxx}
${tz}${prefix}${xxx}urlshort${xxx}
${tz}${prefix}${xxx}shortener${xxx}
${tz}${prefix}${xxx}fox${xxx}
${tz}${prefix}${xxx}dog${xxx}
${tz}${prefix}${xxx}cat${xxx}
${tz}${prefix}${xxx}panda${xxx}
${tz}${prefix}${xxx}panda1${xxx}
${tz}${prefix}${xxx}bird${xxx}
${tz}${prefix}${xxx}koala${xxx}
${tz}${prefix}${xxx}meme${xxx}  
${tz}${prefix}${xxx}asupan${xxx}
${tz}${prefix}${xxx}asupan1${xxx}
${tz}${prefix}${xxx}asupan2${xxx}
${tz}${prefix}${xxx}ngakak${xxx}
${tz}${prefix}${xxx}speed${xxx}
${tz}${prefix}${xxx}pin${xxx} 
${tz}${prefix}${xxx}foto${xxx} 
${tz}${prefix}${xxx}bts${xxx}
${tz}${prefix}${xxx}exo${xxx}
${tz}${prefix}${xxx}blackpink${xxx}
${tz}${prefix}${xxx}attp${xxx}
${tz}${prefix}${xxx}manga1${xxx}
${tz}${prefix}${xxx}character${xxx}
${tz}${prefix}${xxx}ttp4${xxx}
${tz}${prefix}${xxx}ttp3${xxx}
${tz}${prefix}${xxx}ttp2${xxx}
${tz}${prefix}${xxx}ttp1${xxx}
${tz}${prefix}${xxx}sticker${xxx}
${tz}${prefix}${xxx}stickergif${xxx}
${tz}${prefix}${xxx}bug${xxx}

  *◪SERTIFIKAT*
${tz}${prefix}${xxx}ffserti${xxx} 
${tz}${prefix}${xxx}ffserti2${xxx}
${tz}${prefix}${xxx}ffserti3${xxx}
${tz}${prefix}${xxx}ffserti4${xxx}
${tz}${prefix}${xxx}ffserti5${xxx}
${tz}${prefix}${xxx}pubgserti${xxx}
${tz}${prefix}${xxx}pubgserti2${xxx}
${tz}${prefix}${xxx}pubgserti3${xxx}
${tz}${prefix}${xxx}pubgserti4${xxx}
${tz}${prefix}${xxx}pubgserti5${xxx}
${tz}${prefix}${xxx}mlserti${xxx}
${tz}${prefix}${xxx}mlserti2${xxx}
${tz}${prefix}${xxx}mlserti3${xxx}
${tz}${prefix}${xxx}mlserti4${xxx}
${tz}${prefix}${xxx}mlserti5${xxx}

  *◪MAKER FOTO*
${tz}${prefix}${xxx}crossgun${xxx} 
${tz}${prefix}${xxx}bakar${xxx}
${tz}${prefix}${xxx}pensil${xxx}
${tz}${prefix}${xxx}pantaimalam${xxx}
${tz}${prefix}${xxx}costumwp${xxx}
${tz}${prefix}${xxx}facebookpage${xxx}
${tz}${prefix}${xxx}gtav${xxx}
${tz}${prefix}${xxx}deteksiumur${xxx}
${tz}${prefix}${xxx}removebg${xxx}
${tz}${prefix}${xxx}deteksiwajah${xxx}
${tz}${prefix}${xxx}wanted${xxx}

  *◪STICKER MENU*
${tz}${prefix}${xxx}stickbucin${xxx}
${tz}${prefix}${xxx}stickanjing${xxx}
${tz}${prefix}${xxx}gawrgura${xxx}
${tz}${prefix}${xxx}umongus${xxx}
${tz}${prefix}${xxx}dadu${xxx}
${tz}${prefix}${xxx}randompatrick${xxx}
${tz}${prefix}${xxx}randomwibu${xxx}
${tz}${prefix}${xxx}sticker${xxx}

  *◪NEWS MENU*
${tz}${prefix}${xxx}newsdetik${xxx}
${tz}${prefix}${xxx}newskompas${xxx}
${tz}${prefix}${xxx}newskompas${xxx}
${tz}${prefix}${xxx}newstribun${xxx}
${tz}${prefix}${xxx}jalantikus${xxx}

  *◪LIST*
${tz}${prefix}${xxx}allmenu${xxx}
${tz}${prefix}${xxx}mygrub${xxx}
${tz}${prefix}${xxx}request${xxx}
${tz}${prefix}${xxx}ownermed${xxx}


[ Thanks To ]
• ALLAH SWT
• EMAK
• OWNER  
• NAYLA
• PENYEDIA API
• LOL HUMAN
• XTEAM
• 0Z4N-KUN`
}
exports.botx = (prefix) => {
	return`[❗] MODE BOTX TIDAK AKTIF\nKETIK *botx*\nUNTUK MENGAKTIFKAN`
	}
exports.prem1 = (command) => { 
    return`MAAF TAPI FITUR *${command}* KHUSUS MEMBER PREMIUM. INGIN DAFTAR PREMIUM?? SILAHKAN HUBUNGI OWNER`
    }
exports.error = (prefix, command) => {
    return`[❗] ERROR SILAHKAN LAPORKAN KE OWNER. KETIK *bug ${command}*\n[ *APIKEY UNFALID* ]`
    }
exports.info1 = () => { 
    return`🐳 = $200
🦈 = $121
🐬 = $104
🐋 = $94
🐟 = $87
🐠 = $79
🦐 = $62
🦑 = $34
🦀 = $17
🐚 = $2
*NOTE* : TETAPLAH BERBURU KAWAN. WALAUPUN TIDAK BERGUNA SEPERTI ANDA`
  }
exports.info2 = () => { 
    return`🐔 = $200
🦃 = $121
🐿 = $104
🐐 = $94
🐏 = $87
🐖 = $79
🐑 = $62
🐎 = $34
🐺 = $17
🦩 = $2
*NOTE* : TETAPLAH BERBURU KAWAN. WALAUPUN TIDAK BERGUNA SEPERTI ANDA`
}
exports.info3 = () => { 
    return`🦋 = $200
🕷 = $121
🐝 = $104
🐉 = $94
🦆 = $87
🦅 = $79
🕊 = $62
🐧 = $34
🐦 = $17
🦇 = $2
*NOTE* : TETAPLAH BERBURU KAWAN. WALAUPUN TIDAK BERGUNA SEPERTI ANDA`
} 
exports.allmenu = (ownername, auth0r, bulan, tchat, tz, prefix) => {
	return`◪ANDA TAU BABI?
	
*◪GOOGLE SEARCH*
Sus adalah sebuah genus dalam keluarga Suidae. Secara umum, anggota genus Sus disebut babi, baik babi domestik maupun babi hutan. Dengan jumlah sekitar 1 miliar ekor yang hidup setiap saat, babi domestik merupakan salah satu mamalia besar yang populasinya paling banyak di dunia. Wikipedia

  *◪ALL MENU*
${tz}${prefix}${xxx}hidetag${xxx}
${tz}${prefix}${xxx}add${xxx}
${tz}${prefix}${xxx}kick${xxx}
${tz}${prefix}${xxx}promote${xxx}
${tz}${prefix}${xxx}demote${xxx}
${tz}${prefix}${xxx}antilink${xxx}
${tz}${prefix}${xxx}welcome${xxx}
${tz}${prefix}${xxx}level${xxx}
${tz}${prefix}${xxx}limit${xxx}
${tz}${prefix}${xxx}leveling${xxx}
${tz}${prefix}${xxx}hidetag10${xxx}
${tz}${prefix}${xxx}group${xxx}
${tz}${prefix}${xxx}antigay${xxx}
${tz}${prefix}${xxx}antibocil${xxx}
${tz}${prefix}${xxx}antiwibu${xxx}
${tz}${prefix}${xxx}antikasar${xxx}
${tz}${prefix}${xxx}antitag${xxx}
${tz}${prefix}${xxx}antijawa${xxx} 
${tz}${prefix}${xxx}katajago${xxx}
${tz}${prefix}${xxx}linkgc${xxx}
${tz}${prefix}${xxx}tagall${xxx}
${tz}${prefix}${xxx}delete${xxx}
${tz}${prefix}${xxx}stickbucin${xxx}
${tz}${prefix}${xxx}stickanjing${xxx}
${tz}${prefix}${xxx}gawrgura${xxx}
${tz}${prefix}${xxx}umongus${xxx}
${tz}${prefix}${xxx}dadu${xxx}
${tz}${prefix}${xxx}randompatrick${xxx}
${tz}${prefix}${xxx}randomwibu${xxx}
${tz}${prefix}${xxx}sticker${xxx}
${tz}${prefix}${xxx}wallteknologi${xxx}
${tz}${prefix}${xxx}wallhacker${xxx}
${tz}${prefix}${xxx}wallcyber${xxx}
${tz}${prefix}${xxx}wallmuslim${xxx}
${tz}${prefix}${xxx}wallpegunungan${xxx}
${tz}${prefix}${xxx}caklontong${xxx}
${tz}${prefix}${xxx}robot${xxx}
${tz}${prefix}${xxx}3dwhite${xxx}
${tz}${prefix}${xxx}daun${xxx}
${tz}${prefix}${xxx}metal1${xxx}
${tz}${prefix}${xxx}metal${xxx}
${tz}${prefix}${xxx}scary${xxx}
${tz}${prefix}${xxx}imo${xxx}
${tz}${prefix}${xxx}wallpaper${xxx}
${tz}${prefix}${xxx}tahta${xxx}
${tz}${prefix}${xxx}neon2${xxx}
${tz}${prefix}${xxx}wall${xxx}
${tz}${prefix}${xxx}wolf${xxx}
${tz}${prefix}${xxx}tfire${xxx}
${tz}${prefix}${xxx}ytgold${xxx}
${tz}${prefix}${xxx}ytsilver${xxx}
${tz}${prefix}${xxx}t3d${xxx}
${tz}${prefix}${xxx}logoa${xxx}
${tz}${prefix}${xxx}pornhub${xxx}
${tz}${prefix}${xxx}glitchtext${xxx}
${tz}${prefix}${xxx}marvel${xxx}
${tz}${prefix}${xxx}leavest${xxx}
${tz}${prefix}${xxx}phcoment${xxx}
${tz}${prefix}${xxx}nulis${xxx}
${tz}${prefix}${xxx}neon1${xxx}
${tz}${prefix}${xxx}text3d${xxx}
${tz}${prefix}${xxx}galaxy${xxx}
${tz}${prefix}${xxx}gaming${xxx}
${tz}${prefix}${xxx}colors${xxx}
${tz}${prefix}${xxx}kling${xxx}
${tz}${prefix}${xxx}barcode${xxx}
${tz}${prefix}${xxx}qrcode${xxx}
${tz}${prefix}${xxx}8bit${xxx}
${tz}${prefix}${xxx}burn${xxx}
${tz}${prefix}${xxx}fire${xxx}
${tz}${prefix}${xxx}google${xxx}
${tz}${prefix}${xxx}battle${xxx}
${tz}${prefix}${xxx}block${xxx}
${tz}${prefix}${xxx}candy${xxx}
${tz}${prefix}${xxx}potter${xxx}
${tz}${prefix}${xxx}silk${xxx}
${tz}${prefix}${xxx}water${xxx}
${tz}${prefix}${xxx}pubg${xxx}
${tz}${prefix}${xxx}neon${xxx}
${tz}${prefix}${xxx}coffe1${xxx}
${tz}${prefix}${xxx}coffe${xxx}
${tz}${prefix}${xxx}tiktok${xxx}
${tz}${prefix}${xxx}shadow${xxx}
${tz}${prefix}${xxx}romance${xxx}
${tz}${prefix}${xxx}glass${xxx}
${tz}${prefix}${xxx}naruto${xxx}
${tz}${prefix}${xxx}mug1${xxx}
${tz}${prefix}${xxx}love${xxx}
${tz}${prefix}${xxx}mug${xxx}
${tz}${prefix}${xxx}neon1${xxx}
${tz}${prefix}${xxx}smoke${xxx}
${tz}${prefix}${xxx}rainbow${xxx}
${tz}${prefix}${xxx}nulis1${xxx}
${tz}${prefix}${xxx}nulis2${xxx}
${tz}${prefix}${xxx}nulis3${xxx}
${tz}${prefix}${xxx}nulis4${xxx}
${tz}${prefix}${xxx}nulis5${xxx}
${tz}${prefix}${xxx}nulis6${xxx}
${tz}${prefix}${xxx}video1${xxx}
${tz}${prefix}${xxx}video2${xxx}
${tz}${prefix}${xxx}video3${xxx}
${tz}${prefix}${xxx}video4${xxx}
${tz}${prefix}${xxx}video5${xxx}
${tz}${prefix}${xxx}video6${xxx}
${tz}${prefix}${xxx}telesticker${xxx}
${tz}${prefix}${xxx}tiktokmusic${xxx}
${tz}${prefix}${xxx}tiktoknowm${xxx}
${tz}${prefix}${xxx}igfoto${xxx}
${tz}${prefix}${xxx}igvideo${xxx}
${tz}${prefix}${xxx}ytsearch${xxx}
${tz}${prefix}${xxx}ytmp3${xxx}
${tz}${prefix}${xxx}ytmp4${xxx}
${tz}${prefix}${xxx}play${xxx}
${tz}${prefix}${xxx}sound1${xxx}
${tz}${prefix}${xxx}sound2${xxx}
${tz}${prefix}${xxx}sound3${xxx}
${tz}${prefix}${xxx}sound4${xxx}
${tz}${prefix}${xxx}sound5${xxx}
${tz}${prefix}${xxx}sound6${xxx}
${tz}${prefix}${xxx}sound7${xxx}
${tz}${prefix}${xxx}sound8${xxx}
${tz}${prefix}${xxx}sound9${xxx}
${tz}${prefix}${xxx}sound10${xxx}
${tz}${prefix}${xxx}sound11${xxx}
${tz}${prefix}${xxx}sound12${xxx}
${tz}${prefix}${xxx}sound13${xxx}
${tz}${prefix}${xxx}sound14${xxx}
${tz}${prefix}${xxx}sound15${xxx}
${tz}${prefix}${xxx}sound16${xxx}
${tz}${prefix}${xxx}sound17${xxx}
${tz}${prefix}${xxx}sound18${xxx}
${tz}${prefix}${xxx}sound19${xxx}
${tz}${prefix}${xxx}sound20${xxx}
${tz}${prefix}${xxx}sound21${xxx}
${tz}${prefix}${xxx}sound22${xxx}
${tz}${prefix}${xxx}sound23${xxx}
${tz}${prefix}${xxx}sound24${xxx}
${tz}${prefix}${xxx}sound25${xxx}
${tz}${prefix}${xxx}readmore${xxx}
${tz}${prefix}${xxx}chatlist${xxx}
${tz}${prefix}${xxx}addsticker${xxx}
${tz}${prefix}${xxx}addvn${xxx}
${tz}${prefix}${xxx}getvn${xxx}
${tz}${prefix}${xxx}getsticker${xxx}
${tz}${prefix}${xxx}liststicker${xxx}
${tz}${prefix}${xxx}listvn${xxx}
${tz}${prefix}${xxx}addimage${xxx}
${tz}${prefix}${xxx}getimage${xxx}
${tz}${prefix}${xxx}imagelist${xxx}
${tz}${prefix}${xxx}addvideo${xxx}
${tz}${prefix}${xxx}getvideo${xxx}
${tz}${prefix}${xxx}listvideo${xxx}
${tz}${prefix}${xxx}gantengcek${xxx}
${tz}${prefix}${xxx}cantikcek${xxx}
${tz}${prefix}${xxx}jelekcek${xxx}
${tz}${prefix}${xxx}goblokcek${xxx}
${tz}${prefix}${xxx}begocek${xxx}
${tz}${prefix}${xxx}pintercek${xxx}
${tz}${prefix}${xxx}jagocek${xxx}
${tz}${prefix}${xxx}nolepcek${xxx}
${tz}${prefix}${xxx}babicek${xxx}
${tz}${prefix}${xxx}bebancek${xxx}
${tz}${prefix}${xxx}baikcek${xxx}
${tz}${prefix}${xxx}jahatcek${xxx}
${tz}${prefix}${xxx}anjingcek${xxx}
${tz}${prefix}${xxx}haramcek${xxx}
${tz}${prefix}${xxx}kontolcek${xxx}
${tz}${prefix}${xxx}pakboycek${xxx}
${tz}${prefix}${xxx}pakgirlcek${xxx}
${tz}${prefix}${xxx}sangecek${xxx}
${tz}${prefix}${xxx}bapercek${xxx}
${tz}${prefix}${xxx}ganteng${xxx}
${tz}${prefix}${xxx}cantik${xxx}
${tz}${prefix}${xxx}jelek${xxx}
${tz}${prefix}${xxx}goblok${xxx}
${tz}${prefix}${xxx}bego${xxx}
${tz}${prefix}${xxx}pinter${xxx}
${tz}${prefix}${xxx}jago${xxx}
${tz}${prefix}${xxx}babi${xxx}
${tz}${prefix}${xxx}beban${xxx}
${tz}${prefix}${xxx}baik${xxx}
${tz}${prefix}${xxx}jahat${xxx}
${tz}${prefix}${xxx}anjing${xxx}
${tz}${prefix}${xxx}monyet${xxx}
${tz}${prefix}${xxx}haram${xxx}
${tz}${prefix}${xxx}kontol${xxx}
${tz}${prefix}${xxx}pakboy${xxx}
${tz}${prefix}${xxx}pakgirl${xxx}
${tz}${prefix}${xxx}sadboy${xxx}
${tz}${prefix}${xxx}sadgirl${xxx}
${tz}${prefix}${xxx}wibu${xxx}
${tz}${prefix}${xxx}nolep${xxx}
${tz}${prefix}${xxx}hebat${xxx}
${tz}${prefix}${xxx}slot${xxx}
${tz}${prefix}${xxx}simi${xxx}
${tz}${prefix}${xxx}jumlah${xxx}
${tz}${prefix}${xxx}hurufkebalik${xxx}
${tz}${prefix}${xxx}tebakgambar${xxx}
${tz}${prefix}${xxx}nickff${xxx}
${tz}${prefix}${xxx}kapankah${xxx}
${tz}${prefix}${xxx}apakah${xxx}
${tz}${prefix}${xxx}ramalnomer${xxx} 
${tz}${prefix}${xxx}ramalcinta${xxx} 
${tz}${prefix}${xxx}jodohbali${xxx} 
${tz}${prefix}${xxx}ramalnikah${xxx} 
${tz}${prefix}${xxx}taksirmimpi${xxx} 
${tz}${prefix}${xxx}suit${xxx}                   
${tz}${prefix}${xxx}boomtext${xxx}
${tz}${prefix}${xxx}holoh${xxx}
${tz}${prefix}${xxx}heleh${xxx}
${tz}${prefix}${xxx}huluh${xxx}
${tz}${prefix}${xxx}hilih${xxx}
${tz}${prefix}${xxx}halah${xxx} 
${tz}${prefix}${xxx}kapital${xxx}
${tz}${prefix}${xxx}textfont${xxx}
${tz}${prefix}${xxx}tebak${xxx}
${tz}${prefix}${xxx}oxo${xxx}
${tz}${prefix}${xxx}pesan${xxx}
${tz}${prefix}${xxx}tebakkimia${xxx}
${tz}${prefix}${xxx}tebaklirik${xxx}
${tz}${prefix}${xxx}tebakin1${xxx}
${tz}${prefix}${xxx}tebakin2${xxx}
${tz}${prefix}${xxx}quotes2${xxx}
${tz}${prefix}${xxx}quotes1${xxx}
${tz}${prefix}${xxx}kusonime${xxx}
${tz}${prefix}${xxx}renungan${xxx}
${tz}${prefix}${xxx}samehadaku${xxx}
${tz}${prefix}${xxx}infonomer${xxx}
${tz}${prefix}${xxx}jadwaltv${xxx}
${tz}${prefix}${xxx}tvjadwal${xxx}
${tz}${prefix}${xxx}fml${xxx}
${tz}${prefix}${xxx}cinta${xxx}
${tz}${prefix}${xxx}resepmasakan${xxx}
${tz}${prefix}${xxx}cersex${xxx}
${tz}${prefix}${xxx}cerpen${xxx}
${tz}${prefix}${xxx}jadwalsholat${xxx}
${tz}${prefix}${xxx}pantun${xxx}
${tz}${prefix}${xxx}cuaca${xxx}
${tz}${prefix}${xxx}namaninja${xxx}
${tz}${prefix}${xxx}fake${xxx}
${tz}${prefix}${xxx}spamcall${xxx}
${tz}${prefix}${xxx}spamemail${xxx}
${tz}${prefix}${xxx}quotes${xxx}
${tz}${prefix}${xxx}quotesnime${xxx}
${tz}${prefix}${xxx}kbbilazimedia${xxx}
${tz}${prefix}${xxx}covid${xxx}
${tz}${prefix}${xxx}wikiid${xxx}
${tz}${prefix}${xxx}wikien${xxx}
${tz}${prefix}${xxx}covidid${xxx}
${tz}${prefix}${xxx}kbbi${xxx}
${tz}${prefix}${xxx}infogempa${xxx}
${tz}${prefix}${xxx}randomquran${xxx}
${tz}${prefix}${xxx}kisanabi${xxx}
${tz}${prefix}${xxx}artinama${xxx}
${tz}${prefix}${xxx}artimimpi${xxx}
${tz}${prefix}${xxx}artijadian${xxx}
${tz}${prefix}${xxx}chord${xxx}
${tz}${prefix}${xxx}lirik${xxx}
${tz}${prefix}${xxx}fb${xxx}
${tz}${prefix}${xxx}tts${xxx}
${tz}${prefix}${xxx}steam${xxx}
${tz}${prefix}${xxx}stalktwit${xxx}
${tz}${prefix}${xxx}stalkgithub${xxx} 
${tz}${prefix}${xxx}randomhusbu${xxx}
${tz}${prefix}${xxx}pinterest${xxx}
${tz}${prefix}${xxx}randomwaifu${xxx}
${tz}${prefix}${xxx}randomwaifu1${xxx}
${tz}${prefix}${xxx}stalkig${xxx}
${tz}${prefix}${xxx}estetikpic${xxx}
${tz}${prefix}${xxx}memeindo${xxx}
${tz}${prefix}${xxx}darkjokes${xxx}
${tz}${prefix}${xxx}urlshort${xxx}
${tz}${prefix}${xxx}shortener${xxx}
${tz}${prefix}${xxx}fox${xxx}
${tz}${prefix}${xxx}dog${xxx}
${tz}${prefix}${xxx}cat${xxx}
${tz}${prefix}${xxx}panda${xxx}
${tz}${prefix}${xxx}panda1${xxx}
${tz}${prefix}${xxx}bird${xxx}
${tz}${prefix}${xxx}koala${xxx}
${tz}${prefix}${xxx}meme${xxx}  
${tz}${prefix}${xxx}asupan${xxx}
${tz}${prefix}${xxx}asupan1${xxx}
${tz}${prefix}${xxx}asupan2${xxx}
${tz}${prefix}${xxx}ngakak${xxx}
${tz}${prefix}${xxx}pin${xxx} 
${tz}${prefix}${xxx}foto${xxx} 
${tz}${prefix}${xxx}bts${xxx}
${tz}${prefix}${xxx}exo${xxx}
${tz}${prefix}${xxx}blackpink${xxx}
${tz}${prefix}${xxx}attp${xxx}
${tz}${prefix}${xxx}manga1${xxx}
${tz}${prefix}${xxx}character${xxx}
${tz}${prefix}${xxx}ttp4${xxx}
${tz}${prefix}${xxx}ttp3${xxx}
${tz}${prefix}${xxx}ttp2${xxx}
${tz}${prefix}${xxx}ttp1${xxx}
${tz}${prefix}${xxx}sticker${xxx}
${tz}${prefix}${xxx}stickergif${xxx}
${tz}${prefix}${xxx}bug${xxx}
${tz}${prefix}${xxx}ffserti${xxx} 
${tz}${prefix}${xxx}ffserti2${xxx}
${tz}${prefix}${xxx}ffserti3${xxx}
${tz}${prefix}${xxx}ffserti4${xxx}
${tz}${prefix}${xxx}ffserti5${xxx}
${tz}${prefix}${xxx}pubgserti${xxx}
${tz}${prefix}${xxx}pubgserti2${xxx}
${tz}${prefix}${xxx}pubgserti3${xxx}
${tz}${prefix}${xxx}pubgserti4${xxx}
${tz}${prefix}${xxx}pubgserti5${xxx}
${tz}${prefix}${xxx}mlserti${xxx}
${tz}${prefix}${xxx}mlserti2${xxx}
${tz}${prefix}${xxx}mlserti3${xxx}
${tz}${prefix}${xxx}mlserti4${xxx}
${tz}${prefix}${xxx}mlserti5${xxx}
${tz}${prefix}${xxx}dellprem${xxx} 
${tz}${prefix}${xxx}addprem${xxx}
${tz}${prefix}${xxx}clearall${xxx}
${tz}${prefix}${xxx}bc${xxx}
${tz}${prefix}${xxx}owner${xxx}
${tz}${prefix}${xxx}author${xxx}
${tz}${prefix}${xxx}bugtroli${xxx}
${tz}${prefix}${xxx}setout${xxx}
${tz}${prefix}${xxx}setwelcome${xxx}
${tz}${prefix}${xxx}settz${xxx}
${tz}${prefix}${xxx}setthum${xxx}
${tz}${prefix}${xxx}setpp${xxx}
${tz}${prefix}${xxx}setprefix${xxx}
${tz}${prefix}${xxx}setreply${xxx}
${tz}${prefix}${xxx}crossgun${xxx} 
${tz}${prefix}${xxx}bakar${xxx}
${tz}${prefix}${xxx}pensil${xxx}
${tz}${prefix}${xxx}pantaimalam${xxx}
${tz}${prefix}${xxx}costumwp${xxx}
${tz}${prefix}${xxx}facebookpage${xxx}
${tz}${prefix}${xxx}gtav${xxx}
${tz}${prefix}${xxx}deteksiumur${xxx}
${tz}${prefix}${xxx}removebg${xxx}
${tz}${prefix}${xxx}deteksiwajah${xxx}
${tz}${prefix}${xxx}wanted${xxx}
${tz}${prefix}${xxx}randomwibu${xxx}
${tz}${prefix}${xxx}phkomen${xxx}
${tz}${prefix}${xxx}semoji${xxx}
${tz}${prefix}${xxx}jadian${xxx}
${tz}${prefix}${xxx}citacita${xxx}
${tz}${prefix}${xxx}laut${xxx}
${tz}${prefix}${xxx}darat${xxx}
${tz}${prefix}${xxx}udara${xxx}
${tz}${prefix}${xxx}fakta${xxx}
${tz}${prefix}${xxx}gcard${xxx}
${tz}${prefix}${xxx}ssweb${xxx}
${tz}${prefix}${xxx}katailham${xxx}
${tz}${prefix}${xxx}randomwibu${xxx}

${tz} ${xxx}OWNER : ${ownername}${xxx}
${tz} ${xxx}AUTHOR : ${auth0r}${xxx}
${tz} ${xxx}BULAN : ${bulan}${xxx}
${tz} ${xxx}CHAT : ${tchat}${xxx}

NOTE: GK ADA NOTE`
}
exports.kenapasaya = (ownername, pushname, prefix, auth0r, bulan, tz) => {
	return`KENAPA ANDA DI BAN?

*JAWABAN* 
KARNA LO RETARD KEK NOPAL EMOSI

ANDA DI BAN? MUNGKIN KARENA
-SPAM BOT
-CALL BOT
-TOXIC KE BOT
-NGATAIN BOT
-BEDA BEDAIN BOT

KETIK ${prefix}owner
UNTUK CHAT KE OWNER
DAN KATAKAN
*MAAF ATAS KETIDAK SOPANAN SAYA*
*TOLONG BUKA BAN*
*SAYA TIDAK AKAN MENGULANGI PERBUATAN SAYA*

NOTE: KLO ANDA DI BAN ANDA CUMA BISA MENGAKSES
FITUR ${prefix}owner

JANGAN LAKUKAN KESALAHAN ITU!!

*INFO*
${xxx}► Prefix : 「 ${prefix} 」${xxx}
${xxx}► Bulan🌙: ${bulan}${xxx}
${xxx}► Nama : ${pushname}${xxx}
${xxx}► Owner : ${ownername}${xxx}
INGAT YA PERATURANNYA`
}